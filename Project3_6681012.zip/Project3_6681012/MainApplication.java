package Project3_6681012;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class MainApplication extends JFrame 
{
	private int playerCount;
	
	private PlayerFrame [] players;
	private CharSelect setup;
        private String [] names;
	
	private JPanel            contentpane;
	private JComboBox         combo;
    	private ButtonGroup       bgroup;
    	private JButton           startButton;

        private MainApplication   currentFrame;

	public static void main(String []args)
	{	
		new MainApplication();
	}

	public MainApplication()
	{
		setTitle("Card Knight");
		setSize(1366, 768); 
       		setLocationRelativeTo(null);
		setVisible(true);
		setDefaultCloseOperation( WindowConstants.DISPOSE_ON_CLOSE );
        	currentFrame = this;
        
        	contentpane = (JPanel)getContentPane();
		contentpane.setLayout( new BorderLayout(25,25) );        

        	addComponent();
	}

	public void addComponent() 
        {
            startButton = new JButton("Start Game");
            startButton.addActionListener( new ActionListener() {
            @Override
            public void actionPerformed( ActionEvent e )
            {
                InitPlayerFrame(playerCount);
                InitPlayerNames(playerCount);
                new CharSelect(0,currentFrame);
                dispose();
                System.out.println(playerCount);       
            }
        });
        
            Integer[] items = {2, 3, 4, 5, 6};
            combo = new JComboBox(items);
            combo.setSelectedIndex(0);
            setPlayerCount(items[0]);
            combo.addItemListener( new ItemListener() {
            @Override
                public void itemStateChanged( ItemEvent e )
                {
                    int index = combo.getSelectedIndex();
                    setPlayerCount(items[index]);
                }
            });

            JLabel title = new JLabel("Card Knight", SwingConstants.CENTER);
            title.setFont(new Font("Monospaced", Font.PLAIN, 20));

            JPanel start = new JPanel();
            //JPanel top = new JPanel();
            start.add(new JLabel("Players: "));
            start.add(combo);
            start.add(startButton);
            
            contentpane.add(title, BorderLayout.NORTH);
            contentpane.add(start, BorderLayout.CENTER);
            validate();
        }
        
        private void InitPlayerFrame(int player_count)                  { players = new PlayerFrame[player_count]; }
        private void InitPlayerNames(int player_count)                  { names = new String[player_count];}
        
        public void setPlayerCount(int count)                           { playerCount = count; }
        
        public PlayerFrame [] getPlayerFrame()                          { return players; }
        public String [] getPlayersNames()                              { return names; }
        public int getMaxPlayerCount()                                  { return playerCount; }
	

}

interface MyConstants
{
	public static String path = "src/main/java/Project3_6681012/";
        public static String sword = "resources/Sword.png";
        public static String heal = "resources/Heal_1.png";
	public static int card_holder_start_x = 250;
	public static int card_holder_space = 100;
	public static int card_holder_y = 600;
	public static int shield_holder_start_x = 1065;
}

class CharSelect extends JFrame 
{	
	private JPanel contentpane;
        private int Player_pair;
        private PlayerFrame [] tied_playerFrame;
        private String [] tied_names;
        private int Class = 0;
        private MainApplication main;
        
        private JRadioButton [] radio;
        private JButton add_button;
        private JTextField textin;
        
	public CharSelect(int where, MainApplication pf)
	{
            setTitle("Select Your Character");
            setSize(800, 600); 
            setVisible(true);
            setDefaultCloseOperation( WindowConstants.DISPOSE_ON_CLOSE );
            main = pf;
            Player_pair = where;
            
            tied_playerFrame = main.getPlayerFrame();
            tied_names = main.getPlayersNames();
            
            contentpane = (JPanel)getContentPane();
            contentpane.setLayout( new BorderLayout() );
            AddComponents();
	}
        
	public void AddComponents()
	{
            
            add_button = new JButton("Add");
            add_button.addActionListener( new ActionListener() {
            @Override
            public void actionPerformed( ActionEvent e )
            {
                String text = textin.getText();
                if(!text.equals(""))
                {   
                    if(Player_pair < tied_playerFrame.length)
                    {
                        textin.setText("");
                        radio[0].setSelected(true);
                        tied_playerFrame[Player_pair] = new PlayerFrame(Class,text,main);
                        tied_names[Player_pair] = text;
                        incPlayerIndex();
                        if(Player_pair == tied_playerFrame.length)
                        {   
                            tied_playerFrame[0].initFrame(0, main.getMaxPlayerCount());
                            dispose();
                        }
                    }   
                    else
                    {   
                        tied_playerFrame[0].initFrame(0, main.getMaxPlayerCount());
                        dispose();
                    }
                }
                else
                {
                    textin.setToolTipText("Empty Name IS NOT ALLOWED!");
                }
            }
        });
        radio = new JRadioButton[5];
        JPanel rpanel	   = new JPanel(new GridLayout(5,1,20,20));
        ButtonGroup rgroup = new ButtonGroup();
        String items[] = {"Fighter", "Paladin", "Mage", "Cave man", "Normal"};

        for (int i=0; i < 5; i++) 
        {
            // treated as different (final) variables in different iterations
            // new value can be assigned but only in declaration statement
            radio[i] = new JRadioButton( items[i] );
            if (i == 0) radio[i].setSelected(true);
            rgroup.add( radio[i] );
            rpanel.add( radio[i] );

            radio[i].addItemListener( new ItemListener() {
                @Override
		public void itemStateChanged( ItemEvent e )
		{
                    JRadioButton temp = (JRadioButton)e.getItem();
                    //if (temp.isSelected())
                    if (e.getStateChange() == ItemEvent.SELECTED)
                        {
                            int count;
                            String tempstr = temp.getText();
                            switch( tempstr )
                            {
                                case "Fighter":
                                    setClass(1);
                                    break;
                                case "Paldin":
                                    setClass(2);
                                    break;
                                case "Mage":
                                    setClass(3);
                                    break;
                                case "Cave man":
                                    setClass(4);
                                    break;
                                case "Normal":
                                    setClass(5);
                                    break;
                            }
                            //int count = Integer.parseInt( temp.getText() );z
                        }

                    }
                });	
            }
            JPanel north = new JPanel();
            textin = new JTextField(20);
            textin.setToolTipText("Enter chracter name");
            north.add(textin);
            north.add(add_button);

            contentpane.add(north, BorderLayout.NORTH);
            contentpane.add(rpanel, BorderLayout.CENTER);			// using radio buttons (4)
        
            contentpane.validate();
        }
        
        private void setClass(int selected)                     { Class = selected; }
        private void incPlayerIndex()                           { Player_pair++; }
}

class PlayerFrame extends JFrame implements MouseListener
{	
	private String name;
	private int HP;
	private int MP;
	private int DP;
        private int maxPlayer;
        private int round = 0;
        private int player_left;

	private Card activeCard;
        private JPanel contentpane;
        private ArrayList<Card> hands;
	private ArrayList<CardPlace> templateList;
        private PlayerFrame [] players;
        private MainApplication controller;
        private JList list;
	private int target;
        
        public PlayerFrame(int Class, String name, MainApplication pf)
        {   
            this.name = name;
            controller = pf;
            players = controller.getPlayerFrame();
            maxPlayer = controller.getMaxPlayerCount();
            player_left = controller.getMaxPlayerCount();
            hands = new ArrayList<>();
            switch(Class)
            {
                case 0: 
                    HP = 100;
                    MP = 100;
                    DP = 0;
                    break;
                case 1:
                    HP = 120;
                    MP = 80;
                    DP = 0;
                    break;
                case 2:
                    HP = 110;
                    MP = 100;
                    DP = 10;
                    break;
                case 3:
                    HP = 80;
                    MP = 120;
                    DP = 0;
                    break;
                case 4:
                    HP = 140;
                    MP = 60;
                    DP = 20;
                    break;
            }
        }

	public void initFrame(int round, int player_left)
	{           
                this.round = round;
		setTitle(name);
		setSize(1366,768);	
		setVisible(true);
		setResizable(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation( WindowConstants.DISPOSE_ON_CLOSE );
                repaint();
                
		JOptionPane.showMessageDialog(this, HP);
		MyImageIcon bg = new MyImageIcon("src/main/java/Project3_6681012/resources/BG.png").resize(getWidth(), getHeight());

		JLabel background = new JLabel();
                background.setLocation(0, 0);
		templateList = new ArrayList<>();
		
		contentpane = (JPanel)getContentPane();
		background.setIcon(bg);
		background.setLayout(null);

		CardPlace holder1 = new CardPlace("src/main/java/Project3_6681012/resources/Place_holder.png",64,96,this,4);
		holder1.setMoveConditions(250, 600, false, false);	
		
		CardPlace holder2 = new CardPlace("src/main/java/Project3_6681012/resources/Place_holder.png",64,96,this,4);
		holder2.setMoveConditions(350, 600, false, false);	
		
		CardPlace holder3 = new CardPlace("src/main/java/Project3_6681012/resources/Place_holder.png",64,96,this,4);
		holder3.setMoveConditions(450, 600, false, false);

		CardPlace holder4 = new CardPlace("src/main/java/Project3_6681012/resources/Place_holder.png",64,96,this,4);
		holder4.setMoveConditions(550, 600, false, false);

		CardPlace holder5 = new CardPlace("src/main/java/Project3_6681012/resources/Place_holder.png",64,96,this,4);
		holder5.setMoveConditions(650, 600, false, false);

		CardPlace holder_act_1 = new CardPlace("src/main/java/Project3_6681012/resources/Place_holder.png",64,96,this,0);
		holder_act_1.setMoveConditions(250, 400, false, false);

		CardPlace holder_act_2 = new CardPlace("src/main/java/Project3_6681012/resources/Place_holder.png",64,96,this,0);
		holder_act_2.setMoveConditions(350, 400, false, false);

		CardPlace holder_act_3 = new CardPlace("src/main/java/Project3_6681012/resources/Place_holder.png",64,96,this,0);
		holder_act_3.setMoveConditions(450, 400, false, false);

		CardPlace holder_act_4 = new CardPlace("src/main/java/Project3_6681012/resources/Place_holder.png",64,96,this,1);
		holder_act_4.setMoveConditions(550, 400, false, false);	

		CardPlace holder_def1 = new CardPlace("src/main/java/Project3_6681012/resources/Place_holder.png",64,96,this,2);
		holder_def1.setMoveConditions(1065, 600, false, false);

		CardPlace holder_def2 = new CardPlace("src/main/java/Project3_6681012/resources/Place_holder.png",64,96,this,2);
		holder_def2.setMoveConditions(1245, 600, false, false);
                
                JButton next = new JButton("Next");
                next.setBounds(900,600,70,50);
                next.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed( ActionEvent e )
                    {
                            //System.out.println(target);
                            int d = nextPlayer();
                            if(d >= maxPlayer)
                            {   
                                d=0;
                                
                                for(int i=0; i<maxPlayer; i++)
                                {
                                    for(int j=0;j<maxPlayer;j++)
                                    {
                                        ArrayList<CardPlace> list1 = players[i].getTemplateList();
                                        if(j == players[i].getTarget())
                                        {   
//                                            if(list1.get(7).getCard() == null)System.out.println(list1.get(7).getCard().getAttr());
//                                            if(list1.get(8).getCard() == null)System.out.println(list1.get(8).getCard().getAttr());
//                                            if(list1.get(9).getCard() == null)System.out.println(list1.get(9).getCard().getAttr());
                                            players[players[i].getTarget()].setHP(players[players[i].getTarget()].getHP() - new Random().nextInt(1,21));
                                            if(players[target].getHP() < 0 && player_left > 1)
                                            {   
                                                playerReduce();
                                                players[j].setHP(0);  
                                                System.out.println(players[target].getPlayerCount());
                                                if(players[i].getPlayerCount() == 1)
                                                {   
                                                    JOptionPane.showMessageDialog(null,players[j].getPlayerName() + " is the Winner!");
                                                    System.out.println();
                                                    System.exit(0);
                                                }
                                            } 
                                        }                                     
                                    }
                                }
                                for(int i=0;i<maxPlayer;i++)for(int j=0;j<hands.size();j++)clearHands();
                                for(int i=0; i<maxPlayer; i++)System.out.println(players[i].getHP()); 
                                System.out.println();
                            }
                            players[d].initFrame(d,player_left);
                            if(player_left == 1)
                            {
                                
                            }
                            dispose();
                    }
                });
                
                list = new JList( controller.getPlayersNames() );
                list.setBounds(30,600,100,150);
                list.setVisibleRowCount(5);
                list.addListSelectionListener( new ListSelectionListener() {
                    @Override
                    public void valueChanged( ListSelectionEvent e )
                    {
                        if( !e.getValueIsAdjusting() )
                        {
                            setSelectedTarget(list.getSelectedIndex()); 
                            //System.out.println(list.getSelectedIndex());
                        }
                    }
                });
                                
                background.add(list);
                background.add(next);
                
                templateList.add(holder1);
		templateList.add(holder2);
		templateList.add(holder3);
		templateList.add(holder4);
		templateList.add(holder5);
		templateList.add(holder_def1);
		templateList.add(holder_def2);
		templateList.add(holder_act_1);
		templateList.add(holder_act_2);
		templateList.add(holder_act_3);
		templateList.add(holder_act_4);
                
                String [] cardNamelist = {MyConstants.sword, MyConstants.heal, "resources/Card_template_real.png"};
                for(int i=0;i<5;i++)
                {   
                    String tmp_text = cardNamelist[new Random().nextInt(0,cardNamelist.length)];
                    int type=0;
                    int attr=0;
                    switch(tmp_text)
                    {
                        case MyConstants.sword:
                            type = 0;
                            attr = 2;
                            break;
                        case "resources/Card_template_real.png":
                            type = 0;
                            attr = 1;
                            break;
                        case MyConstants.heal:
                            type = 1;
                            attr = 2;
                            break;
                        
                    }
                    Card temp = new Card(MyConstants.path + tmp_text,64,96,this,type,attr);
                    temp.setMoveConditions(templateList.get(i).getX(), templateList.get(i).getY(), true, true);
                    background.add(temp);
                    hands.add(temp);
                    setActiveCard(temp);
                    snapCheck();
                }

                background.add(holder1);
		background.add(holder2);
		background.add(holder3);
		background.add(holder4);
		background.add(holder5);
		
		background.add(holder_act_1);
		background.add(holder_act_2);
		background.add(holder_act_3);
		background.add(holder_act_4);
		
		background.add(holder_def1);
		background.add(holder_def2);
                


		contentpane.add(background, null);
                
		
		contentpane.validate();
		addMouseListener(this);	
	}

	public void setActiveCard(Card card)			{ activeCard = card; }
	public Card getActiveCard()				{ return activeCard; }

	public void snapCheck()						
	{ 	
		boolean intersectAny = false;
		for(int i=0;i<templateList.size();i++)
		{
			if(templateList.get(i).getBounds().intersects(activeCard.getBounds()))
			{
				if((!templateList.get(i).isOccupied() && (activeCard.getCardType() == templateList.get(i).getSlotType())) || (templateList.get(i).getSlotType() == 4 && !templateList.get(i).isOccupied()))
				{	
					intersectAny = true;
					templateList.get(i).Occupied(activeCard);
					activeCard.setMoveConditions(templateList.get(i).getX(),templateList.get(i).getY(),true,true);
					
					if(activeCard.getCurSlot() != null)activeCard.getCurSlot().freeSlot();

					activeCard.occupiedSlot(templateList.get(i));
					templateList.get(i).Occupied(activeCard);
					break;
				}
				else
				{	
					intersectAny = true;
					if((activeCard.getCurSlot() != null && activeCard.getCardType() == templateList.get(i).getSlotType()) || (templateList.get(i).getSlotType() == 4 && templateList.get(i).getSlotType() == activeCard.getCurSlot().getSlotType()))
					{
						CardPlace tempC = templateList.get(i);

						if(activeCard.getCurSlot().equals(templateList.get(i))){ activeCard.setMoveConditions(tempC.getX(),tempC.getY(),true,true); break; }

						int tempX = tempC.getX();
						int tempY = tempC.getY();
						Card tempCard = tempC.getCard();

						tempCard.setMoveConditions(activeCard.getCurSlot().getX(),activeCard.getCurSlot().getY(),true,true);
						activeCard.setMoveConditions(tempX,tempY,true,true);

						activeCard.getCurSlot().freeSlot();
					
						tempC.getCard().occupiedSlot(activeCard.getCurSlot());
						activeCard.getCurSlot().Occupied(tempC.getCard());
						activeCard.occupiedSlot(tempC);
						tempC.Occupied(activeCard);
					}
                                        if(activeCard.getCardType() != templateList.get(i).getSlotType() && activeCard.getCurSlot() != null)activeCard.setMoveConditions(activeCard.getCurSlot().getX(),activeCard.getCurSlot().getY(),true,true);
					break;
				}
			}
		}
		if(!intersectAny)
		{
			if(activeCard.getCurSlot() != null)activeCard.setMoveConditions(activeCard.getCurSlot().getX(),activeCard.getCurSlot().getY(),true,true);
		}   
	}
        
	public void mousePressed( MouseEvent e )			{ } 
    	public void mouseEntered( MouseEvent e )			{ }
    	public void mouseExited( MouseEvent e )				{ }
    	public void mouseMoved( MouseEvent e )				{ }
    	public void mouseClicked( MouseEvent e )			{ }	
    	
        public void mouseReleased( MouseEvent e )			{ snapCheck(); }
        
        private void setSelectedTarget(int target)                      { this.target = target; }
        private int nextPlayer()                                        { round = (round + 1); return round; }
        private void clearHands()                                       { for(int i=0;i<hands.size();i++)contentpane.remove(hands.get(i));hands.clear(); }
        
        public int getHP()                                              { return HP; }
        public int getMP()                                              { return MP; }
        public int getDP()                                              { return DP; }
        public int getTarget()                                          { return target; }
        public int getPlayerCount()                                     { return player_left; }
        public ArrayList<CardPlace> getTemplateList()                   { return templateList; }
        public String getPlayerName()                                   { return name; }
        public void setHP(int new_HP)                                   { HP = new_HP; }
        public void setMP(int new_MP)                                   { MP = new_MP; }
        public void setDP(int new_DP)                                   { DP = new_DP; }
        public void playerLeave()                                       { player_left--; }
        public void playerReduce()                                      { for(int i=0;i<players.length;i++)players[i].playerLeave();}
      
}

abstract class BaseLabel extends JLabel
{
    	protected MyImageIcon      iconMain, iconAlt;
   	protected int              curX, curY, width, height;
    	protected boolean          horizontalMove, verticalMove;
    	protected PlayerFrame      parentFrame;

    	public BaseLabel() { }
    	public BaseLabel(String file1, int w, int h, PlayerFrame pf)
    	{
        	width = w; height = h;
        	iconMain = new MyImageIcon(file1).resize(width, height);
		setHorizontalAlignment(JLabel.CENTER);
		setIcon(iconMain);
        	parentFrame = pf;
        	iconAlt = null;
    	}
    
    	public BaseLabel(String file1, String file2, int w, int h, PlayerFrame pf)
    	{
        	this(file1, w, h, pf);
        	iconAlt = new MyImageIcon(file2).resize(width, height);
    	}

    	public void setMoveConditions(boolean hm, boolean vm)
    	{
       		horizontalMove = hm;
        	verticalMove   = vm;
    	}


    	public void setMoveConditions(int x, int y, boolean hm, boolean vm)
    	{
        	curX = x; curY = y;
        	setBounds(curX, curY, width, height);
        	setMoveConditions(hm, vm);
    	}

    	abstract public void updateLocation();
}

class CardPlace extends BaseLabel
{	
	private boolean isOccupied = false;
	private Card occupiedCard;

	private int type;

    	public CardPlace(String file, int w, int h, PlayerFrame pf, int type)
    	{
        	// Alternative icon = null
                super(file, w, h, pf);
                this.type = type;
    	}

    	public void updateLocation() { }

    	public void setMainIcon()       		{ setIcon(iconMain); }
    	public void setAltIcon()        		{ setIcon(iconAlt); }

	public void Occupied(Card card)			{ isOccupied = true; occupiedCard = card; }
	public void freeSlot()				{ isOccupied = false; occupiedCard = null; }
	public boolean isOccupied()			{ return isOccupied; }
	public Card getCard()				{ return occupiedCard; }
        
        public int getSlotType()                        { return type; }
        
}

class Card extends BaseLabel implements MouseMotionListener, MouseListener
{
    	private CardPlace curSlot = null;
        private int type;
        private int attr;
	
	public Card(String file, int w, int h, PlayerFrame pf, int type, int attr)
    	{
        	// Alternative icon = null
        	super(file, w, h, pf);
                this.type = type;
                this.attr = attr;
        	addMouseMotionListener(this);
		addMouseListener(this);
    	}	

    	public void updateLocation()
    	{
    		int f_width = parentFrame.getContentPane().getWidth();
		int f_height = parentFrame.getContentPane().getHeight();

		if(curX+width >= f_width)curX=f_width-width;
		else if(curX <= 0)curX=0;
		if(curY + height >= f_height)curY=f_height-height;
		else if(curY <= 0)curY=0;

		setBounds(curX, curY, width, height);
		setLocation(curX,curY);
    	}

    	public void setMainIcon()       				{ setIcon(iconMain); }
    	public void setAltIcon()        				{ setIcon(iconAlt); }

    	public void mousePressed( MouseEvent e )			{ parentFrame.setActiveCard(this); } 
    	public void mouseEntered( MouseEvent e )			{ }
    	public void mouseExited( MouseEvent e )				{ }
    	public void mouseMoved( MouseEvent e )				{ }
    	public void mouseClicked( MouseEvent e )			{ }
	


    	public void mouseReleased( MouseEvent e )			{ parentFrame.snapCheck(); }

    	public void mouseDragged(MouseEvent e)
    	{
	   	curX=curX - width/2 + e.getX();
	   	curY=curY - height/2 + e.getY();
	   	updateLocation();
    	}

	public void occupiedSlot(CardPlace slot)			{ curSlot = slot; }
	public CardPlace getCurSlot()					{ return curSlot; }
        
        public int getCardType()                                        { return type; }
        public int getAttr()                                            { return attr; }

}

class MyImageIcon extends ImageIcon
{
    	public MyImageIcon(String fname)  { super(fname); }
    	public MyImageIcon(Image image)   { super(image); }

    	public MyImageIcon resize(int width, int height)
    	{
		Image oldimg = this.getImage();
		Image newimg = oldimg.getScaledInstance(width, height, java.awt.Image.SCALE_SMOOTH);
        	return new MyImageIcon(newimg);
    	}
}
